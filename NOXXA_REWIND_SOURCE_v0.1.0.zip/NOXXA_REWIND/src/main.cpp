#include <mod/amlmod.h>
#include <mod/logger.h>
#include <mod/config.h>
#include <isautils.h>

#include <aml-psdk/game_sa/Events.h>

#include "RewindAudio.hpp"
#include "RewindCore.hpp"
#include "RewindUI.hpp"

#include <string>

MYMODCFG(net.noxxa.rewind, NOXXA REWIND, 0.1.0, henn)
NEEDGAME(com.rockstargames.gtasa)

BEGIN_DEPLIST()
    ADD_DEPENDENCY_VER(net.rusjj.aml, 1.4.0)
    ADD_DEPENDENCY_VER(net.rusjj.gtasa.utils, 1.4)
END_DEPLIST()

namespace {

ISAUtils* g_saUtils = nullptr;
noxxa::RewindAudio g_audio;
noxxa::RewindCore g_core;
noxxa::RewindUI g_ui;

std::string JoinPath(const char* root, const char* suffix) {
    std::string out = root ? root : "";
    if (!out.empty() && out.back() != '/') out.push_back('/');
    out += suffix;
    return out;
}

} // namespace

ON_MOD_LOAD()
{
    logger->SetTag("NOXXA REWIND");

#ifndef AML32
    logger->Error("v0.1 targets GTA SA v2.00 / armeabi-v7a first.");
    aml->ShowToast(true, "NOXXA REWIND v0.1: 32-bit GTA SA v2.00 build required");
    return;
#endif

    g_saUtils = reinterpret_cast<ISAUtils*>(GetInterface("SAUtils"));
    if (!g_saUtils) {
        logger->Error("SAUtils interface is missing.");
        aml->ShowToast(true, "NOXXA REWIND: SAUtils is required");
        return;
    }

    noxxa::RewindSettings settings;
    settings.historySeconds = cfg->GetFloat("HistorySeconds", 8.0f, "Rewind");
    settings.snapshotHz = cfg->GetInt("SnapshotHz", 60, "Rewind");
    settings.rewindSpeed = cfg->GetFloat("RewindSpeed", 2.0f, "Rewind");
    settings.quickSeconds = cfg->GetFloat("QuickRewindSeconds", 3.0f, "Rewind");
    settings.haptics = cfg->GetBool("Haptics", true, "Effects");

    const float buttonX = cfg->GetFloat("ButtonX", 0.88f, "UI");
    const float buttonY = cfg->GetFloat("ButtonY", 0.62f, "UI");
    const float buttonScale = cfg->GetFloat("ButtonScale", 1.0f, "UI");

    const std::string assetDir = JoinPath(aml->GetAndroidDataRootPath(), "mods/NoxxaRewind");
    const std::string loopWav = JoinPath(assetDir.c_str(), "rewind_loop.wav");
    const std::string releaseWav = JoinPath(assetDir.c_str(), "rewind_release.wav");
    const std::string buttonPng = JoinPath(assetDir.c_str(), "rewind_button.png");

    if (!g_audio.Init(loopWav, releaseWav)) {
        logger->Error("Audio assets failed to load. Core rewind will still run.");
    }

    g_ui.Init(g_saUtils, buttonPng, buttonX, buttonY, buttonScale);
    g_core.Init(settings, &g_audio);

    Events::gameProcessEvent.before += []()
    {
        g_core.BeforeGameProcess();
    };

    // Apply rewind after GTA finishes the frame's gameplay update. This prevents
    // normal physics from instantly overwriting the restored state before render.
    Events::gameProcessEvent.after += []()
    {
        const noxxa::RewindInput input = g_ui.PollInput();
        g_core.Tick(input.held, input.released, input.doubleTapped);
    };

    Events::drawHudEvent += []()
    {
        g_ui.DrawHud(g_core);
    };

    logger->Info("Loaded: %.1fs history, %d Hz snapshots, %.2fx rewind",
                 settings.historySeconds, settings.snapshotHz, settings.rewindSpeed);
}
