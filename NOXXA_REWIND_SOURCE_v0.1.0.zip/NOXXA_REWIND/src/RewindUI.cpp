#include "RewindUI.hpp"
#include "RewindCore.hpp"

#include <mod/amlmod.h>
#include <isautils.h>
#include <aml-psdk/game_sa/engine/Font.h>
#include <algorithm>
#include <cstdio>

namespace noxxa {

RewindUI* RewindUI::s_instance = nullptr;

bool RewindUI::Init(ISAUtils* utils, const std::string& buttonPng, float xNorm, float yNorm, float scale) {
    m_utils = utils;
    m_buttonPng = buttonPng;
    m_xNorm = std::clamp(xNorm, 0.05f, 0.95f);
    m_yNorm = std::clamp(yNorm, 0.05f, 0.95f);
    m_scale = std::clamp(scale, 0.5f, 2.0f);
    if (!m_utils) return false;

    s_instance = this;
    m_utils->AddOnWidgetsCreateListener(WidgetsCreateThunk);
    return true;
}

void RewindUI::WidgetsCreateThunk() {
    if (s_instance) s_instance->CreateWidget();
}

void RewindUI::CreateWidget() {
    if (!m_utils || m_widget) return;

    int width = 1920, height = 1080;
    if (aml) aml->GetDisplaySize(&width, &height);
    m_widgetId = m_utils->FindFreeWidgetId();
    if (m_widgetId < 0) return;

    const int x = static_cast<int>(width * m_xNorm);
    const int y = static_cast<int>(height * m_yNorm);
    m_widget = m_utils->CreateWidget(m_widgetId, x, y, m_scale, nullptr);
    if (!m_widget) return;

    void* texture = m_utils->LoadRwTextureFromPNG(m_buttonPng.c_str());
    if (texture) m_utils->SetWidgetIcon(m_widget, reinterpret_cast<uintptr_t>(texture));
    m_utils->ToggleWidget(m_widget, true);
}

RewindInput RewindUI::PollInput() const {
    RewindInput input{};
    if (!m_utils || !m_widget) return input;

    // Widget_IsTouched is continuous while the finger remains on the button.
    // Do not depend on WState_HeldDown: SAUtils exposes the enum, but the
    // current 1.4 implementation does not implement a HeldDown switch case.
    input.held = m_utils->GetWidgetState(m_widget, WState_Touched) != 0;
    input.released = m_utils->GetWidgetState(m_widget, WState_Released) != 0;
    input.doubleTapped = m_utils->GetWidgetState(m_widget, WState_DoubleTapped) != 0;
    return input;
}

void RewindUI::DrawHud(const RewindCore& core) const {
    if (!core.IsRewinding()) return;

    char text[96];
    std::snprintf(text, sizeof(text), "REWINDING  -%.1fs   /   %.1fs", core.RewoundSeconds(), core.AvailableSeconds());

    CRGBA drop(0, 0, 0, 220);
    CFont::SetScale(1.45f);
    CFont::SetWrapx(1000000.0f);
    CFont::SetJustify(0);
    CFont::SetEdge(2);
    CFont::SetFontStyle(FO_FONT_STYLE_STANDARD);
    CFont::SetOrientation(ALIGN_LEFT);
    CFont::SetProportional(1);
    CFont::SetDropColor(drop);
    CFont::PrintString(65.0f, 65.0f, text);
    CFont::RenderFontBuffer();
}

} // namespace noxxa
