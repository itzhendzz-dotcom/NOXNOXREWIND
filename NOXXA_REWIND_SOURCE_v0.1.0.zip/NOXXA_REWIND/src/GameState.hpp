#pragma once

#include <cstdint>
#include <aml-psdk/gta_base/Vector.h>

class CPhysical;
class CPlayerPed;
class CVehicle;

namespace noxxa {

struct TransformState {
    bool hasMatrix{false};
    CVector right{};
    CVector forward{}; // CMatrix::up = GTA forward
    CVector up{};      // CMatrix::at = GTA up
    CVector position{};
    float heading{0.0f};
};

struct PhysicalState {
    TransformState transform{};
    CVector moveSpeed{};
    CVector turnSpeed{};
};

struct RewindFrame {
    uint64_t sequence{0};

    // Context boundary. V1 intentionally does not rewind through
    // enter/exit vehicle transitions; that requires task restoration.
    uintptr_t vehicleToken{0};
    bool inVehicle{false};

    PhysicalState player{};
    float playerHealth{0.0f};
    float playerArmour{0.0f};
    float playerCurrentRotation{0.0f};
    float playerAimingRotation{0.0f};

    PhysicalState vehicle{};
    float vehicleHealth{0.0f};
};

class GameStateAdapter {
public:
    bool Capture(RewindFrame& out, uint64_t sequence) const;
    bool Apply(const RewindFrame& frame) const;
    uintptr_t CurrentVehicleToken() const;
    void QuiesceCurrentContext() const;

private:
    static void CapturePhysical(CPhysical* physical, PhysicalState& out);
    static void ApplyPhysical(CPhysical* physical, const PhysicalState& state);
};

} // namespace noxxa
