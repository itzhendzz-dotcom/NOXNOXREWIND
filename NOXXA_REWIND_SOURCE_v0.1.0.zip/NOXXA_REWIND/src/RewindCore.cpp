#include "RewindCore.hpp"
#include "RewindAudio.hpp"

#include <mod/amlmod.h>
#include <algorithm>
#include <cmath>

namespace noxxa {

void RewindCore::Init(const RewindSettings& settings, RewindAudio* audio) {
    m_settings = settings;
    m_settings.historySeconds = std::clamp(m_settings.historySeconds, 2.0f, 20.0f);
    m_settings.snapshotHz = std::clamp(m_settings.snapshotHz, 15, 120);
    m_settings.rewindSpeed = std::clamp(m_settings.rewindSpeed, 0.5f, 4.0f);
    m_settings.quickSeconds = std::clamp(m_settings.quickSeconds, 0.5f, m_settings.historySeconds);

    const auto capacity = static_cast<std::size_t>(std::ceil(m_settings.historySeconds * m_settings.snapshotHz)) + 2;
    m_timeline.SetCapacity(capacity);
    m_audio = audio;
    m_lastTick = Clock::now();
}

void RewindCore::BeforeGameProcess() {
    if (m_rewinding) m_game.QuiesceCurrentContext();
}

void RewindCore::Tick(bool holdDown, bool released, bool doubleTapped) {
    const auto now = Clock::now();
    double dt = std::chrono::duration<double>(now - m_lastTick).count();
    m_lastTick = now;
    dt = std::clamp(dt, 0.0, 0.100); // don't explode after app pause/resume

    if (!m_rewinding) {
        Record(dt);

        if (doubleTapped) {
            BeginRewind(true);
        } else if (holdDown) {
            BeginRewind(false);
        }
    }

    if (m_rewinding) {
        ProcessRewind(dt, holdDown, released);
    }
}

void RewindCore::Record(double dt) {
    const double period = 1.0 / static_cast<double>(m_settings.snapshotHz);
    m_recordAccumulator += dt;

    // At most four samples in one game frame. If the process was stalled longer,
    // duplicating old state is worse than dropping history granularity.
    int captures = 0;
    while (m_recordAccumulator >= period && captures < 4) {
        RewindFrame frame{};
        if (m_game.Capture(frame, ++m_sequence)) m_timeline.Push(frame);
        m_recordAccumulator -= period;
        ++captures;
    }
    if (captures == 4 && m_recordAccumulator > period * 4.0) m_recordAccumulator = 0.0;
}

bool RewindCore::BeginRewind(bool quickMode) {
    // Capture the exact present before entering rewind so the first backward step
    // starts from what the player is actually seeing.
    RewindFrame now{};
    if (m_game.Capture(now, ++m_sequence)) m_timeline.Push(now);
    if (!m_timeline.BeginRewind()) return false;

    m_rewinding = true;
    m_quickMode = quickMode;
    m_rewindAccumulator = 0.0;
    m_rewindStartCursor = m_timeline.Cursor();
    m_rewindVehicleToken = m_game.CurrentVehicleToken();
    m_quickFramesRemaining = quickMode
        ? static_cast<std::size_t>(std::round(m_settings.quickSeconds * m_settings.snapshotHz))
        : 0;

    if (m_audio) m_audio->StartLoop();
    if (m_settings.haptics && aml) aml->DoVibro(18);
    return true;
}

bool RewindCore::TryStepBack() {
    const RewindFrame* candidate = m_timeline.PeekStepBack();
    if (!candidate) return false;

    // V1 safety boundary: do not cross an enter/exit vehicle transition.
    // Reconstructing GTA's task tree is a separate feature, not something to fake.
    if (candidate->vehicleToken != m_rewindVehicleToken) return false;

    const RewindFrame* frame = m_timeline.StepBack();
    if (!frame || !m_game.Apply(*frame)) return false;

    if (m_quickMode && m_quickFramesRemaining > 0) --m_quickFramesRemaining;
    return true;
}

void RewindCore::ProcessRewind(double dt, bool holdDown, bool released) {
    if (!m_quickMode && released) {
        EndRewind(true);
        return;
    }
    if (!m_quickMode && !holdDown) {
        // SAUtils may report Released for one frame only; this makes release robust.
        EndRewind(true);
        return;
    }

    const double framesPerSecond = static_cast<double>(m_settings.snapshotHz) * m_settings.rewindSpeed;
    m_rewindAccumulator += dt * framesPerSecond;

    int stepsThisTick = 0;
    while (m_rewindAccumulator >= 1.0 && stepsThisTick < 12) {
        if (m_quickMode && m_quickFramesRemaining == 0) {
            EndRewind(true);
            return;
        }
        if (!TryStepBack()) {
            EndRewind(true);
            return;
        }
        m_rewindAccumulator -= 1.0;
        ++stepsThisTick;
    }
}

void RewindCore::EndRewind(bool commit) {
    if (!m_rewinding) return;

    // The pre-process guard zeroes velocity to reduce forward physics side
    // effects. Re-apply the selected historic frame once more before commit so
    // release preserves the recorded momentum exactly.
    if (const RewindFrame* selected = m_timeline.Current()) m_game.Apply(*selected);

    if (commit) m_timeline.CommitRewind();
    else m_timeline.CancelRewind();

    m_rewinding = false;
    m_quickMode = false;
    m_quickFramesRemaining = 0;
    m_recordAccumulator = 0.0;
    m_rewindAccumulator = 0.0;

    if (m_audio) m_audio->StopWithRelease();
    if (m_settings.haptics && aml) aml->DoVibro(12);
}

float RewindCore::RewoundSeconds() const {
    if (!m_rewinding || m_rewindStartCursor < m_timeline.Cursor()) return 0.0f;
    return static_cast<float>(m_rewindStartCursor - m_timeline.Cursor()) /
           static_cast<float>(m_settings.snapshotHz);
}

float RewindCore::AvailableSeconds() const {
    if (m_timeline.Size() < 2) return 0.0f;
    return static_cast<float>(m_timeline.Size() - 1) /
           static_cast<float>(m_settings.snapshotHz);
}

} // namespace noxxa
