#pragma once

#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>
#include <atomic>
#include <cstdint>
#include <string>
#include <vector>

namespace noxxa {

class RewindAudio {
public:
    ~RewindAudio();

    bool Init(const std::string& loopWav, const std::string& releaseWav);
    void StartLoop();
    void StopWithRelease();
    void Stop();
    bool Ready() const { return m_ready; }

private:
    struct PcmClip {
        uint32_t sampleRate{0};
        uint16_t channels{0};
        std::vector<int16_t> samples;
    };

    static bool LoadPcm16Wav(const std::string& path, PcmClip& out);
    static void BufferCallback(SLAndroidSimpleBufferQueueItf queue, void* context);
    void OnBufferFinished();
    bool Enqueue(const PcmClip& clip);
    void Destroy();

    PcmClip m_loop;
    PcmClip m_release;
    std::atomic<bool> m_looping{false};
    bool m_ready{false};

    SLObjectItf m_engineObject{nullptr};
    SLEngineItf m_engine{nullptr};
    SLObjectItf m_outputMixObject{nullptr};
    SLObjectItf m_playerObject{nullptr};
    SLPlayItf m_player{nullptr};
    SLAndroidSimpleBufferQueueItf m_queue{nullptr};
};

} // namespace noxxa
