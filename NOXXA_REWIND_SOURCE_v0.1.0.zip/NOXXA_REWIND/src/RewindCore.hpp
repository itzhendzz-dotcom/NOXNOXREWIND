#pragma once

#include "GameState.hpp"
#include "TimelineBuffer.hpp"

#include <chrono>
#include <cstdint>

namespace noxxa {

class RewindAudio;

struct RewindSettings {
    float historySeconds{8.0f};
    int snapshotHz{60};
    float rewindSpeed{2.0f};
    float quickSeconds{3.0f};
    bool haptics{true};
};

class RewindCore {
public:
    void Init(const RewindSettings& settings, RewindAudio* audio);
    void BeforeGameProcess();
    void Tick(bool holdDown, bool released, bool doubleTapped);

    bool IsRewinding() const { return m_rewinding; }
    float RewoundSeconds() const;
    float AvailableSeconds() const;
    std::size_t FrameCount() const { return m_timeline.Size(); }

private:
    using Clock = std::chrono::steady_clock;

    void Record(double dt);
    bool BeginRewind(bool quickMode);
    void ProcessRewind(double dt, bool holdDown, bool released);
    void EndRewind(bool commit = true);
    bool TryStepBack();

    RewindSettings m_settings{};
    TimelineBuffer<RewindFrame> m_timeline{480};
    GameStateAdapter m_game{};
    RewindAudio* m_audio{nullptr};

    Clock::time_point m_lastTick{};
    double m_recordAccumulator{0.0};
    double m_rewindAccumulator{0.0};
    uint64_t m_sequence{0};
    std::size_t m_rewindStartCursor{0};
    std::size_t m_quickFramesRemaining{0};
    uintptr_t m_rewindVehicleToken{0};
    bool m_rewinding{false};
    bool m_quickMode{false};
};

} // namespace noxxa
