#include "GameState.hpp"

#include <aml-psdk/game_sa/entity/PlayerPed.h>
#include <aml-psdk/game_sa/entity/Vehicle.h>
#include <aml-psdk/game_sa/entity/Physical.h>
#include <aml-psdk/game_sa/base/Matrix.h>

namespace noxxa {

void GameStateAdapter::CapturePhysical(CPhysical* physical, PhysicalState& out) {
    if (!physical) return;

    if (CMatrix* matrix = physical->GetMatrix()) {
        out.transform.hasMatrix = true;
        out.transform.right = matrix->right;
        out.transform.forward = matrix->up;
        out.transform.up = matrix->at;
        out.transform.position = matrix->pos;
    } else {
        out.transform.hasMatrix = false;
        out.transform.position = physical->m_placement.m_vPosn;
        out.transform.heading = physical->m_placement.m_fHeading;
    }

    out.moveSpeed = physical->m_vecMoveSpeed;
    out.turnSpeed = physical->m_vecTurnSpeed;
}

void GameStateAdapter::ApplyPhysical(CPhysical* physical, const PhysicalState& state) {
    if (!physical) return;

    if (state.transform.hasMatrix) {
        if (!physical->GetMatrix()) physical->AllocateMatrix();
        if (CMatrix* matrix = physical->GetMatrix()) {
            matrix->right = state.transform.right;
            matrix->up = state.transform.forward;
            matrix->at = state.transform.up;
            matrix->pos = state.transform.position;
            matrix->UpdateRW();
        }
    } else {
        physical->m_placement.m_vPosn = state.transform.position;
        physical->m_placement.m_fHeading = state.transform.heading;
        if (CMatrix* matrix = physical->GetMatrix()) {
            matrix->SetRotateZ(state.transform.heading);
            matrix->SetTranslateOnly(state.transform.position.x,
                                     state.transform.position.y,
                                     state.transform.position.z);
            matrix->UpdateRW();
        }
    }

    // Restoring velocity is the difference between a useful rewind and a
    // teleport gimmick: release resumes from the old momentum.
    physical->m_vecMoveSpeed = state.moveSpeed;
    physical->m_vecTurnSpeed = state.turnSpeed;
    physical->UpdateRwFrame();
}


void GameStateAdapter::QuiesceCurrentContext() const {
    CPlayerPed* player = FindPlayerPed(-1);
    if (!player) return;

    CPhysical* physical = player;
    if (player->bInVehicle && player->m_pVehicle && IsVehiclePointerValid(player->m_pVehicle)) {
        physical = player->m_pVehicle;
    }

    // GTA still executes a normal forward Process() while we are scrubbing the
    // history. Killing motion before that tick greatly reduces accidental
    // forward collisions/impulses; the historical velocity is restored after.
    physical->m_vecMoveSpeed = CVector{};
    physical->m_vecTurnSpeed = CVector{};
}

uintptr_t GameStateAdapter::CurrentVehicleToken() const {
    CPlayerPed* player = FindPlayerPed(-1);
    if (!player || !player->bInVehicle || !player->m_pVehicle) return 0;
    if (!IsVehiclePointerValid(player->m_pVehicle)) return 0;
    return reinterpret_cast<uintptr_t>(player->m_pVehicle);
}

bool GameStateAdapter::Capture(RewindFrame& out, uint64_t sequence) const {
    CPlayerPed* player = FindPlayerPed(-1);
    if (!player) return false;

    out = {};
    out.sequence = sequence;
    out.playerHealth = player->m_fHealth;
    out.playerArmour = player->m_fArmour;
    out.playerCurrentRotation = player->m_fCurrentRotation;
    out.playerAimingRotation = player->m_fAimingRotation;

    CVehicle* vehicle = nullptr;
    if (player->bInVehicle && player->m_pVehicle && IsVehiclePointerValid(player->m_pVehicle)) {
        vehicle = player->m_pVehicle;
    }

    out.inVehicle = vehicle != nullptr;
    out.vehicleToken = reinterpret_cast<uintptr_t>(vehicle);

    if (vehicle) {
        CapturePhysical(vehicle, out.vehicle);
        out.vehicleHealth = vehicle->m_fHealth;
        // The ped is constrained to the vehicle by GTA tasks. Capturing the car
        // is the stable V1 path; rewinding the ped matrix independently causes
        // seat/animation fighting.
    } else {
        CapturePhysical(player, out.player);
    }

    return true;
}

bool GameStateAdapter::Apply(const RewindFrame& frame) const {
    CPlayerPed* player = FindPlayerPed(-1);
    if (!player) return false;

    const uintptr_t currentVehicle = CurrentVehicleToken();
    if (currentVehicle != frame.vehicleToken) return false; // context boundary

    player->m_fHealth = frame.playerHealth;
    player->m_fArmour = frame.playerArmour;
    player->m_fCurrentRotation = frame.playerCurrentRotation;
    player->m_fAimingRotation = frame.playerAimingRotation;

    if (frame.inVehicle) {
        auto* vehicle = reinterpret_cast<CVehicle*>(frame.vehicleToken);
        if (!vehicle || !IsVehiclePointerValid(vehicle)) return false;
        ApplyPhysical(vehicle, frame.vehicle);
        vehicle->m_fHealth = frame.vehicleHealth;
        player->SetPedPositionInCar();
    } else {
        ApplyPhysical(player, frame.player);
    }

    return true;
}

} // namespace noxxa
