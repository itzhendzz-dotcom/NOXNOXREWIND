#pragma once

#include <string>

class ISAUtils;
class CWidgetButton;

namespace noxxa {

struct RewindInput {
    bool held{false};
    bool released{false};
    bool doubleTapped{false};
};

class RewindCore;

class RewindUI {
public:
    bool Init(ISAUtils* utils, const std::string& buttonPng, float xNorm, float yNorm, float scale);
    RewindInput PollInput() const;
    void DrawHud(const RewindCore& core) const;
    bool Ready() const { return m_widget != nullptr; }

private:
    static void WidgetsCreateThunk();
    void CreateWidget();

    ISAUtils* m_utils{nullptr};
    CWidgetButton* m_widget{nullptr};
    std::string m_buttonPng;
    float m_xNorm{0.88f};
    float m_yNorm{0.62f};
    float m_scale{1.0f};
    int m_widgetId{-1};

    static RewindUI* s_instance;
};

} // namespace noxxa
