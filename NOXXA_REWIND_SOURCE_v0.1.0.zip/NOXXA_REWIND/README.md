# NOXXA REWIND

**Wrong move? Undo reality.**

NOXXA REWIND is an experimental native rewind system for GTA: San Andreas Android. It records a short rolling history of the player's physical state and lets the player hold an on-screen button to scrub backward, then release to branch the timeline from the chosen moment.

The design target is the *feel* of a cinematic time-rewind mechanic such as *Life is Strange*, while using original UI/audio assets and a GTA-specific state model rather than copying proprietary game assets.

## What v0.1 actually records

At 60 snapshots/sec by default:

- player transform when on foot;
- player linear + angular velocity;
- health and armour;
- current/aiming rotation;
- current vehicle transform while driving/riding;
- vehicle linear + angular velocity;
- vehicle health;
- the vehicle identity as a safety boundary.

The default history is 8 seconds. With only the player/current vehicle in v0.1, this is intentionally cheap enough to prioritize smooth gameplay rather than trying to rewind the whole city immediately.

## Why it is not a teleport mod

When a recorded frame is restored, NOXXA REWIND restores both transform **and velocity**. That matters because releasing a rewind before a crash should resume from the old motion vector, not teleport the car to an old coordinate while keeping future momentum.

The rewind is processed after GTA's normal game update so the restored state is the state that reaches rendering, instead of letting a forward physics tick immediately overwrite it.

## Timeline branching

The timeline buffer has a rewind cursor. While the button is held the cursor moves backward. On release, every snapshot newer than that cursor is deleted; recording resumes from the selected past frame.

```text
OLD
A ─ B ─ C ─ D ─ CRASH
        ↑ rewind

NEW
A ─ B ─ C
        └─ E ─ F ─ ...
```

## Input

- Hold: manual rewind.
- Release: commit selected past point.
- Double tap: quick rewind 3 seconds (configurable).

SAUtils provides the custom Android widget state API used for touch handling.

## Sound

The repository contains two **original procedurally synthesized** audio assets:

- `audio/rewind_loop.wav`
- `audio/rewind_release.wav`

They are intentionally designed around reverse-motion cues, low rumble, airy movement and crystalline transients without copying or extracting audio from *Life is Strange*.

Playback uses an Android OpenSL ES simple PCM buffer queue. This is a pragmatic fit for a native NDK mod targeting API 21-era compatibility; the code keeps the audio layer isolated so it can later be replaced by Oboe/AAudio if desired.

## Architecture

```text
GameStateAdapter
  capture/apply GTA physical state
        │
        ▼
TimelineBuffer<RewindFrame>
  rolling history + rewind cursor
        │
        ▼
RewindCore
  record / hold / quick rewind / branch commit
        │
        ├── RewindUI (SAUtils + GTA HUD)
        └── RewindAudio (OpenSL ES)
```

The nearby-entity system planned for later can be another adapter rather than rewriting the core timeline logic.

## Performance philosophy

v0.1 deliberately does **not** record dozens of world entities yet. The first milestone is a stable rewind kernel with predictable memory and zero save corruption. Once that is proven, nearby vehicles/peds can use a lower snapshot frequency (for example 20–30 Hz) and a fixed radius while the local player/current vehicle remain at 60 Hz.

## Build

See [`INSTALL.md`](INSTALL.md). GitHub Actions is included.

## Research/design notes

See [`RESEARCH_AND_DESIGN.md`](RESEARCH_AND_DESIGN.md) for references, implementation rationale, risks and the Phase 2/3 plan.

## License

GPL-3.0. The project builds against AML-PSDK, which is GPL-3.0. AML and SAUtils are fetched as pinned external dependencies by the bootstrap script and retain their own upstream licenses.
