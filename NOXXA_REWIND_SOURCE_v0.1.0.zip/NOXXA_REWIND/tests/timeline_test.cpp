#include "../src/TimelineBuffer.hpp"
#include <cassert>
#include <iostream>

int main() {
    noxxa::TimelineBuffer<int> t(5);
    for (int i = 0; i < 7; ++i) t.Push(i);
    assert(t.Size() == 5);
    assert(t.Front() == 2 && t.Back() == 6);

    assert(t.BeginRewind());
    assert(*t.Current() == 6);
    assert(*t.StepBack() == 5);
    assert(*t.StepBack() == 4);
    t.CommitRewind();

    assert(t.Size() == 3);
    assert(t.Back() == 4);
    t.Push(99);
    assert(t.Back() == 99);
    std::cout << "TimelineBuffer tests passed\n";
    return 0;
}
