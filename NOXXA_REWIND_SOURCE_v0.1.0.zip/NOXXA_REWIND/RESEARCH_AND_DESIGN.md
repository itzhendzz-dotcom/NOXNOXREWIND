# NOXXA REWIND — Research and Engineering Design

## Executive conclusion

A convincing rewind on GTA SA Android is feasible without attempting to reverse the physics engine itself. The safer model is **record → playback past states → branch**: capture a compact rolling series of authoritative game states, apply them backward while the input is held, and delete the abandoned future when the player releases.

For the first build, the project should aggressively prefer determinism and stability over scope. Rewinding the player and the player's current vehicle gives the mechanic its useful core while keeping entity lifetime, AI task restoration, streaming and mission-script side effects out of the first crash surface.

## 1. Interaction reference: what makes a rewind feel like a mechanic rather than an undo button

Analysis of *Life is Strange* consistently describes the power as an immediate button-driven rewind that allows an action/choice to be undone and replayed. Its value is not only state correction; it keeps the player inside the scene and turns reconsideration into an embodied interaction. [1][2]

For NOXXA REWIND that translates to four UX rules:

1. **Hold = continuous temporal control.** The player chooses how far to go back rather than selecting a fixed checkpoint.
2. **Release = new present.** The game must continue naturally from the selected frame instead of replaying the abandoned future.
3. **Short history, fast access.** A several-second rolling window is more useful in driving/combat than save-state-sized rewinds.
4. **Strong audiovisual feedback.** Rewind needs a recognisable sonic layer and visible timeline state, otherwise it reads as lag/teleportation.

The project uses original synthesized rewind audio rather than copyrighted *Life is Strange* sound files.

## 2. Why AML + AML-PSDK is the right native layer

Android Mod Loader (AML) loads native `.so` mods and exposes hooking, patching, paths, configuration, display size and vibration APIs. Its current development documentation describes NDK shared-library mods and C++17 builds. [3]

AML-PSDK exposes GTA SA classes and events in a form aligned with plugin-sdk naming. Its README currently lists support for GTA SA Android v2.00 and v2.10 64-bit, and requires Android NDK / C++17 or newer. [4]

The specific pieces required by this project are already represented upstream:

- `FindPlayerPed` and `FindPlayerVehicle` helpers in `PlayerPed.h`. [5]
- `CPhysical::m_vecMoveSpeed` and `m_vecTurnSpeed`, which let the rewind restore momentum rather than coordinates alone. [6]
- `CPlaceable::GetMatrix`, `GetPosition` and transform storage. [7]
- `CMatrix` basis/position fields plus `UpdateRW`. [8]
- player health/armour and rotation fields in `CPed`. [9]
- vehicle health in `CVehicle`. [10]
- `Events::gameProcessEvent` and `drawHudEvent`; AML-PSDK also supports `.after` handlers. [11][12]

This is why the implementation does not need a pile of hard-coded raw struct offsets in v0.1.

## 3. Touch input: use a game-native widget rather than stealing volume buttons

SAUtils exposes custom widget creation and explicit states including touch, release, double tap and hold. It also provides PNG texture loading for widget icons. [13][14]

That maps directly to the requested interaction:

```text
hold        -> rewind continuously
release     -> commit this moment
DoubleTap   -> rewind ~3 seconds automatically
```

The button is generated as an original transparent PNG and installed alongside the sound files. Position and scale are configuration values.

## 4. Snapshot model

v0.1 stores a `RewindFrame` with:

```text
player
  health / armour
  current + aiming rotation
  transform + linear/angular velocity (on foot)

current vehicle (if any)
  identity pointer token
  transform
  linear/angular velocity
  health
```

At the default 60 Hz and 8 seconds, the timeline contains roughly 480 frames. This is intentionally high-frequency for only one or two physical entities so 60/90/120 Hz play does not feel like a 10 Hz position slideshow.

Later, world entities should use a separate lower-rate adapter rather than multiplying this 60 Hz record by 40–100 peds/cars.

## 5. Why velocity restoration matters

A position-only rewind fails immediately in driving:

```text
car crashes at 30 m/s
rewind coordinate by 3 seconds
release
old/future velocity survives
car instantly launches from the restored point
```

NOXXA REWIND stores both `m_vecMoveSpeed` and `m_vecTurnSpeed`. A restored vehicle therefore resumes with the old linear and angular momentum associated with that frame. The PSDK physical class exposes both vectors directly. [6]

## 6. Apply after gameplay update

GTA still runs forward internally. The mod is not trying to integrate negative delta-time through RenderWare/physics/AI.

Instead:

```text
GTA Process() forward tick
        ↓
NOXXA gameProcessEvent.after
        ↓
apply selected historic transform + velocity + health
        ↓
render
```

AML-PSDK exposes `gameProcessEvent`, and its event implementation supports an `.after` listener form used by upstream code. [11][12]

This minimizes the chance that a forward physics tick immediately cancels the rewind state before the frame is shown.

## 7. Vehicle-entry/exit boundary is deliberately blocked in v0.1

Crossing from on-foot to in-vehicle is not merely a transform change. GTA has ped tasks, seat state, vehicle references, animations, camera mode and control state around that transition.

Therefore each frame carries a `vehicleToken`. Rewind may only move through frames with the same current-vehicle context. When the next older frame crosses that boundary, rewind stops cleanly.

This is an important engineering choice: **do not fake task restoration with a teleport.** Phase 2 can implement an explicit transition adapter after the kernel is stable.

## 8. Timeline branching

The timeline is a bounded deque/ring-like history with a rewind cursor.

Normal recording:

```text
[A][B][C][D][E] <- newest
```

Rewind cursor after moving back:

```text
[A][B][C][D][E]
       ^
```

On release:

```text
[A][B][C]
```

`D/E` are erased; future recording starts after `C`. A host-side unit test in `tests/timeline_test.cpp` verifies capacity eviction, backward stepping, branch commit and continued recording.

## 9. Audio implementation

Android's NDK documentation supports Android Simple Buffer Queues for PCM playback and explicitly describes the Android simple buffer queue as a supported source for an audio player. [15][16]

The project therefore includes a tiny OpenSL ES PCM WAV loader/player:

- start rewind → clear queue and loop `rewind_loop.wav`;
- release → stop looping, clear queue and play `rewind_release.wav`;
- no copyrighted game audio is bundled.

The audio class is isolated because OpenSL ES is an older API and can be replaced later without touching timeline/game-state code.

## 10. Life-is-Strange-inspired audiovisual direction without cloning assets

Target language:

- soft desaturation rather than heavy bloom;
- edge/chromatic displacement only while rewinding;
- short temporal ghost trails from recent transforms;
- low rumble + airy reverse movement + brittle high-frequency texture;
- tiny haptic click entering/exiting rewind;
- world SFX duck/crossfade so the rewind layer reads clearly.

v0.1 ships the original loop/release sound and touch icon. Chromatic warp, ghost rendering and world-audio ducking are intentionally held for Phase 2 so the first test isolates state correctness.

## 11. Main crash risks and mitigations

| Risk | Why it is dangerous | v0.1 mitigation |
|---|---|---|
| Stale vehicle pointer | streamed/deleted entity memory can be reused | validate current vehicle and stop at context boundary |
| Vehicle task fight | ped matrix and seat task can disagree | rewind vehicle transform, then call ped seat positioning |
| Physics snap after release | restored coordinate but wrong velocity | restore move + turn velocity |
| Huge world snapshot | memory + CPU + stale entities | player/current vehicle only in v0.1 |
| App pause creates giant dt | timeline jumps many frames | clamp real tick delta |
| WASTED transition | death changes tasks/camera/game logic | Death Rewind deferred |
| Mission scripting | script state may not match restored geometry | first tests should be free-roam; script adapter is future work |

## 12. Phase plan

### Phase 1 — kernel (included now)

- 8 s rolling timeline.
- 60 Hz player/current-vehicle snapshots.
- transform + momentum + HP/armour + vehicle health.
- hold/release/double-tap input.
- timeline branch commit.
- original rewind loop + release sting.
- lightweight HUD text and custom icon.
- GitHub Actions build.

### Phase 2 — the “Life is Strange feel” pass

- screen desaturation/chromatic edge warp.
- motion/temporal ghost trail.
- normal-world audio ducking and clean crossfade.
- variable rewind speed + audio intensity.
- timeline marker events (collision / explosion / near-death).
- safe weapon/ammo + wanted restoration.
- explicit vehicle-enter/exit restoration.

### Phase 3 — world bubble

- fixed-radius vehicle/ped registry.
- stable entity handles instead of trusting raw pointer identity alone.
- 20–30 Hz nearby-entity history + interpolation.
- destroyed/created entity reconciliation.
- fire/explosion/event adapters.
- Death/WASTED rewind only after task/camera restoration is proven.

## 13. Sources

1. Game Developer, “My Favorite Features — Time Rewind in Life is Strange,” 2019. https://www.gamedeveloper.com/design/my-favorite-features---time-rewind-in-life-is-strange
2. Game Developer, “Life is Strange: A Retrospective.” https://www.gamedeveloper.com/design/life-is-strange-a-retrospective
3. Android Mod Loader development documentation. https://github.com/RusJJ/AndroidModLoader/blob/main/docs/DOCUMENTATION_EN.MD
4. AndroidModLoader/aml-psdk README. https://github.com/AndroidModLoader/aml-psdk
5. AML-PSDK `PlayerPed.h`. https://github.com/AndroidModLoader/aml-psdk/blob/main/aml-psdk/game_sa/entity/PlayerPed.h
6. AML-PSDK `Physical.h`. https://github.com/AndroidModLoader/aml-psdk/blob/main/aml-psdk/game_sa/entity/Physical.h
7. AML-PSDK `Placeable.h`. https://github.com/AndroidModLoader/aml-psdk/blob/main/aml-psdk/game_sa/entity/Placeable.h
8. AML-PSDK `Matrix.h`. https://github.com/AndroidModLoader/aml-psdk/blob/main/aml-psdk/game_sa/base/Matrix.h
9. AML-PSDK `Ped.h`. https://github.com/AndroidModLoader/aml-psdk/blob/main/aml-psdk/game_sa/entity/Ped.h
10. AML-PSDK `Vehicle.h`. https://github.com/AndroidModLoader/aml-psdk/blob/main/aml-psdk/game_sa/entity/Vehicle.h
11. AML-PSDK `Events.h`. https://github.com/AndroidModLoader/aml-psdk/blob/main/aml-psdk/game_sa/Events.h
12. AML-PSDK `ThreadSyncer.h` (`gameProcessEvent.after` usage). https://github.com/AndroidModLoader/aml-psdk/blob/main/aml-psdk/game_sa/utils/ThreadSyncer.h
13. SAUtils `isautils.h` widget states / widget API. https://github.com/AndroidModLoader/SAUtils/blob/main/isautils.h
14. SAUtils PNG texture API. https://github.com/AndroidModLoader/SAUtils
15. Android Developers, “Android extensions — OpenSL ES,” Android NDK. https://developer.android.com/ndk/guides/audio/opensl/android-extensions
16. Android Developers, “OpenSL ES for Android,” Android NDK. https://developer.android.com/ndk/guides/audio/opensl/opensl-for-android

